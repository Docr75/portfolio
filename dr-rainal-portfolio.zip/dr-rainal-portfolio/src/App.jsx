import React, { useState } from 'react';
import { 
  Menu, X, Mail, Phone, Globe, MapPin, 
  BookOpen, Briefcase, GraduationCap, Award, 
  Code, Users, FileText, ChevronRight
} from 'lucide-react';

const Portfolio = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const scrollToSection = (id) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800">
      {/* Navigation */}
      <nav className="fixed w-full bg-white/90 backdrop-blur-md shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex-shrink-0 font-bold text-xl tracking-tight text-slate-900">
              Dr. Rainal Hidayat
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex space-x-8">
              {['About', 'Experience', 'Education', 'Publications', 'Skills'].map((item) => (
                <button 
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="text-slate-600 hover:text-indigo-600 font-medium transition-colors"
                >
                  {item}
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center">
              <button onClick={toggleMenu} className="text-slate-600 hover:text-slate-900 focus:outline-none">
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-100">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {['About', 'Experience', 'Education', 'Publications', 'Skills'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="block w-full text-left px-3 py-2 text-base font-medium text-slate-700 hover:text-indigo-600 hover:bg-slate-50 rounded-md"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="hero" className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12">
          <div className="flex-1 space-y-6">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 leading-tight">
              Hi, I'm <span className="text-indigo-600">Ts. Dr. Rainal Hidayat</span>
            </h1>
            <p className="text-xl sm:text-2xl text-slate-600 font-medium">
              Senior Lecturer & Textile Designer
            </p>
            <p className="text-lg text-slate-500 max-w-2xl leading-relaxed">
              Experienced academic and researcher specializing in design thinking methodology, qualitative and quantitative analysis, and academic writing.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <button onClick={() => scrollToSection('contact')} className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-sm">
                Get in Touch
              </button>
              <button onClick={() => scrollToSection('publications')} className="px-6 py-3 bg-white text-slate-700 border border-slate-200 font-medium rounded-lg hover:bg-slate-50 transition-colors shadow-sm">
                View Research
              </button>
            </div>
          </div>
          <div className="flex-1 flex justify-center md:justify-end">
            <div className="w-64 h-64 sm:w-80 sm:h-80 bg-gradient-to-tr from-indigo-100 to-slate-200 rounded-full border-8 border-white shadow-xl flex items-center justify-center overflow-hidden">
                <span className="text-slate-400 font-medium text-lg text-center px-4">
                  [ Portrait of Dr. Rainal ]
                </span>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-6 flex items-center">
                <Users className="mr-3 text-indigo-600" /> About Me
              </h2>
              <div className="space-y-4 text-lg text-slate-600 leading-relaxed">
                <p>
                  I am a Senior Lecturer at Universiti Teknologi MARA (UiTM), Faculty of Art & Design. My expertise lies in design thinking methodology, thematic and content analysis, and postgraduate supervision.
                </p>
                <p>
                  As a digital textile designer, I combine creativity with advanced software skills to design and produce textiles for fashion, interior, and industrial applications with precision. I also serve as a Professional Technologist (MBOT) and have held key roles such as Coordinator for the UiTM Green Centre (UGC).
                </p>
              </div>
            </div>
            <div className="bg-indigo-50 rounded-2xl p-8 border border-indigo-100 shadow-sm relative">
              <div className="text-6xl text-indigo-200 absolute top-4 left-4 font-serif">"</div>
              <p className="text-xl italic text-slate-700 relative z-10 pt-4 leading-relaxed font-serif">
                As an expert in design, my teaching philosophy is centered around creating an immersive and engaging learning environment that encourages creativity, critical thinking, and technical excellence. I believe that art and design are vital disciplines that play a crucial role in shaping culture.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-10 flex items-center justify-center">
            <Briefcase className="mr-3 text-indigo-600" /> Professional Experience
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center mb-6">
                <GraduationCap size={24} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Senior Lecturer</h3>
              <p className="text-slate-600 mb-4">Universiti Teknologi MARA (UiTM)</p>
              <p className="text-sm text-slate-500 leading-relaxed">
                Teaching advanced design principles, supervising Master's and PhD research, developing curriculum, mentoring students, and leading projects integrating creativity and sustainable practices.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center mb-6">
                <Code size={24} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Textile Designer</h3>
              <p className="text-slate-600 mb-4">Digital & Industrial Applications</p>
              <p className="text-sm text-slate-500 leading-relaxed">
                Creating fabric patterns and prints using digital tools. Combining creativity with software skills to design, visualize, and produce textiles with precision and efficiency.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center mb-6">
                <Globe size={24} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Web Administrator</h3>
              <p className="text-slate-600 mb-4">Digital Management</p>
              <p className="text-sm text-slate-500 leading-relaxed">
                Managing and maintaining websites, ensuring functionality and performance. Designing web layouts and optimizing user experiences to support organizational goals.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Education & Awards */}
      <section id="education" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            
            {/* Education */}
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-8 flex items-center">
                <BookOpen className="mr-3 text-indigo-600" /> Education
              </h2>
              <div className="space-y-8 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-300 before:to-transparent">
                
                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-indigo-100 text-indigo-600 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                    <GraduationCap size={18} />
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded border border-slate-100 bg-white shadow-sm">
                    <div className="flex items-center justify-between space-x-2 mb-1">
                      <div className="font-bold text-slate-900">Ph.D. Visual Art</div>
                      <time className="font-mono text-xs text-indigo-600">2016</time>
                    </div>
                    <div className="text-sm text-slate-500">University of Malaya, Kuala Lumpur</div>
                  </div>
                </div>

                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-100 text-slate-600 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                    <BookOpen size={18} />
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded border border-slate-100 bg-white shadow-sm">
                    <div className="flex items-center justify-between space-x-2 mb-1">
                      <div className="font-bold text-slate-900">M.A Art & Design Education</div>
                      <time className="font-mono text-xs text-indigo-600">2000</time>
                    </div>
                    <div className="text-sm text-slate-500">De Monfort University, Leicester, UK</div>
                  </div>
                </div>

                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-100 text-slate-600 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                    <BookOpen size={18} />
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded border border-slate-100 bg-white shadow-sm">
                    <div className="flex items-center justify-between space-x-2 mb-1">
                      <div className="font-bold text-slate-900">B.A Textile Design</div>
                      <time className="font-mono text-xs text-indigo-600">1997</time>
                    </div>
                    <div className="text-sm text-slate-500">Institut Teknologi MARA, Shah Alam</div>
                  </div>
                </div>

              </div>
            </div>

            {/* Awards */}
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-8 flex items-center">
                <Award className="mr-3 text-indigo-600" /> Awards & Recognition
              </h2>
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-100 p-6 rounded-xl shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-lg text-slate-900">Senior Innovator Gold Award</h3>
                    <span className="bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full font-bold">2024</span>
                  </div>
                  <p className="text-slate-600 text-sm">Social Success Autism App, Smart Innovation Competition</p>
                  <p className="text-slate-500 text-xs mt-2">Sibu Innovation Hub</p>
                </div>

                <div className="bg-slate-50 border border-slate-100 p-6 rounded-xl shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-lg text-slate-900">Piala Seri Endon Award</h3>
                    <span className="bg-slate-200 text-slate-700 text-xs px-2 py-1 rounded-full font-bold">2015</span>
                  </div>
                  <p className="text-slate-600 text-sm">Winner of the award for outstanding innovation and creativity in Malaysian batik design and craftsmanship.</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Publications Section */}
      <section id="publications" className="py-20 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold flex items-center justify-center mb-4">
              <FileText className="mr-3 text-indigo-400" /> Selected Research & Publications
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              A brief selection of recent academic contributions focused on design, AI, cultural heritage, and education.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {[
              "An Integrated Reciprocal Human AI Socio-Technical Framework: Enhancing Creative Synergy in Crowdsourced Design (2025)",
              "Reconceptualizing Intellectual Property in AI-Generated Content with Ethical and Legal Implications for Malaysian Designers (2025)",
              "Modeling the Influence of Cultural Graphics on Urban Perception in Qinzhou City: A Structural Equation Approach [Scopus] (2025)",
              "Leveraging Visual-Spatial Abilities to Unlock Speech: An Arts-Based Interdisciplinary Approach to Promoting Inclusion and Equity for Children with Autism (2024)",
              "Predicting Organizational Performance Through Digital Design Tool Adoption in Chinese Graphic Design Agencies (2024)",
              "Social Fluency for Autism: A Caretaker's Handbook [Physical Book] (2024)",
            ].map((pub, index) => (
              <div key={index} className="bg-slate-800 p-6 rounded-xl border border-slate-700 hover:border-indigo-500 transition-colors flex items-start">
                <ChevronRight className="text-indigo-400 mt-1 shrink-0 mr-3" size={20} />
                <p className="text-slate-300 leading-relaxed text-sm">
                  {pub}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-10 flex items-center justify-center text-center">
            <Code className="mr-3 text-indigo-600" /> Software & Technical Skills
          </h2>
          
          <div className="flex flex-wrap justify-center gap-4 max-w-3xl mx-auto">
            {['WordPress', 'Adobe After Effects', 'Adobe Illustrator', 'CLO3D', 'Adobe Photoshop', 'Joomla', 'Sketchup', 'AutoDesk Alias', 'Mockshop', 'ArchiCAD'].map((skill) => (
              <span key={skill} className="px-5 py-3 bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-full font-medium shadow-sm hover:bg-indigo-100 transition-colors">
                {skill}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section & Footer */}
      <section id="contact" className="bg-slate-50 border-t border-slate-200 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8 md:p-12 mb-16 transform -translate-y-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">Get in Touch</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mb-4">
                  <Phone size={20} />
                </div>
                <h4 className="font-bold text-slate-900 mb-1">Phone</h4>
                <a href="tel:+6012226449" className="text-slate-600 hover:text-indigo-600 transition-colors">+601 2226449</a>
              </div>

              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mb-4">
                  <Mail size={20} />
                </div>
                <h4 className="font-bold text-slate-900 mb-1">Email</h4>
                <a href="mailto:rainzwar@uitm.edu.my" className="text-slate-600 hover:text-indigo-600 transition-colors">rainzwar@uitm.edu.my</a>
              </div>

              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mb-4">
                  <Globe size={20} />
                </div>
                <h4 className="font-bold text-slate-900 mb-1">Website</h4>
                <a href="https://www.drrainal.com" target="_blank" rel="noopener noreferrer" className="text-slate-600 hover:text-indigo-600 transition-colors">www.drrainal.com</a>
              </div>

              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mb-4">
                  <MapPin size={20} />
                </div>
                <h4 className="font-bold text-slate-900 mb-1">Address</h4>
                <p className="text-slate-600 text-sm">64 Jalan 15/4/2 Suria Enclave,<br/>Puncak Alam Selangor</p>
              </div>

            </div>
          </div>

          <div className="text-center text-slate-500 text-sm flex flex-col items-center justify-center space-y-2">
            <p>&copy; {new Date().getFullYear()} Ts. Dr. Rainal Hidayat. All rights reserved.</p>
            <p>Universiti Teknologi MARA (UiTM) | Faculty of Art & Design</p>
          </div>
        </div>
      </section>

    </div>
  );
};

export default Portfolio;